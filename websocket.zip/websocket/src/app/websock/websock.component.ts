import { Component, OnDestroy } from '@angular/core';
import { WebsockServiceService } from '../websock-service.service';
import { Subscription } from 'rxjs';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-websock',
  templateUrl: './websock.component.html',
  styleUrls: ['./websock.component.css']
})
export class WebsockComponent implements OnDestroy {
private messageSubscription:Subscription;

messages:String[]=[];
form=new FormGroup({
  namee:new FormControl('')
})

// messages=[];

  constructor(private websocketService:WebsockServiceService){
    this.messageSubscription=this.websocketService.onMessage()
    .subscribe((message)=>{console.log('Received message:',message);
    this.messages.push(message);
  })
  }

onSend(){
  this.websocketService.sendMessage(this.form.value.namee );
  console.log("web socket finished");
  
  console.log(this.form.value.namee);
  this.form.get('namee')?.reset();
  // this.form.reset();
  
}

ngOnDestroy(): void {
  this.messageSubscription.unsubscribe();
}

}
